function encode()
{

    var plain_text = document.getElementById("encode_input").value;
    plain_text = plain_text.toLowerCase();
    var cypher_text = [];
    var alphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

    for(var idx=0; idx<plain_text.length; idx++)
    {
        input = alphabet.indexOf(plain_text[idx]);
        if(input == -1 )
        {
            cypher_text.push(plain_text[idx]);
        }
        else
        {
            var coded = (input+13)%26;
            var letter = alphabet[coded];
            cypher_text.push(letter);
        }
    }
        document.getElementById("encode_output").innerHTML = cypher_text.join("");
}
function decode()
{
  var plain_text = document.getElementById("decode_input").value;
  plain_text = plain_text.toLowerCase();
  var cypher_text = [];

  var alphabet=['z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h','g','f','e','d','c','b','a']

  for(var idx=0; idx<plain_text.length; idx++)
  {
      input = alphabet.indexOf(plain_text[idx]);
      if(input == -1 )
      {
          cypher_text.push(plain_text[idx]);
      }
      else
      {
          var coded = (input+13)%26;
          var letter = alphabet[coded];
          cypher_text.push(letter);
      }
  }
      document.getElementById("decode_output").innerHTML = cypher_text.join("");
}
//    console.log(plain_text)
//    console.log(cypher_text.join(""))
